from app import db
from .site_category import SiteCategory

# جداول العلاقات
article_categories = db.Table('article_categories',
    db.Column('article_id', db.Integer, db.ForeignKey('article_request.id'), primary_key=True),
    db.Column('category_id', db.Integer, db.ForeignKey('category.id'), primary_key=True),
    db.Column('tag_id', db.Integer, db.ForeignKey('tag.id'), primary_key=True)
)

article_tags = db.Table('article_tags',
    db.Column('article_id', db.Integer, db.ForeignKey('article_request.id'), primary_key=True),
    db.Column('tag_id', db.Integer, db.ForeignKey('tag.id'), primary_key=True)
)

# جدول العلاقة بين التصنيفات والوسوم
category_tags = db.Table('category_tags',
    db.Column('category_id', db.Integer, db.ForeignKey('category.id'), primary_key=True),
    db.Column('tag_id', db.Integer, db.ForeignKey('tag.id'), primary_key=True)
)
# استيراد النماذج للإتاحة
from .site import Site, SiteProfile
from .category import Category
from .tag import Tag
from .article import ArticleRequest

# جعل النماذج متاحة عند استيراد الحزمة
__all__ = ['Site', 'SiteProfile', 'Category', 'Tag', 'ArticleRequest']