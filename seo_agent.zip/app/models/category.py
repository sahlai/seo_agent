from app import db

class Category(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    site_id = db.Column(db.Integer, db.ForeignKey('site.id'), nullable=False)
    name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text)
    sites = db.relationship('Site', secondary='site_categories', backref='site_categories')
    slug = db.Column(db.String(100))
    parent_id = db.Column(db.Integer, db.ForeignKey('category.id'))
    
    # العلاقة مع التصنيف الأب
    parent = db.relationship('Category', remote_side=[id], backref=db.backref('children'))
    
    # العلاقة مع الوسوم
    tags = db.relationship('Tag', secondary='category_tags',
        backref=db.backref('categories', lazy='dynamic'))

    def __repr__(self):
        return f'<Category {self.name}>'