from app import db

class SiteCategory(db.Model):
    __tablename__ = 'site_categories'
    id = db.Column(db.Integer, primary_key=True)
    site_id = db.Column(db.Integer, db.ForeignKey('site.id'))
    category_id = db.Column(db.Integer, db.ForeignKey('category.id'))